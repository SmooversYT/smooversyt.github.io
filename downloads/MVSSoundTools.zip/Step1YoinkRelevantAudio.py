import os
import shutil

UASSET_MEDIA_PATH = b'/Game/WwiseAudio/Localized/English_US_/Media/'
WINDOWS_MEDIA_PATH = '../../../../Media/'
WWISE_UNPACKER_GAME_FILES_PATH = './Wwise-Unpacker-1.0.3/Game Files/'
WWISE_UNPACKER_MP3_PATH = './Wwise-Unpacker-1.0.3/MP3/'

output_text = ''
for filename in os.listdir('.'):
    if '.uasset' in filename:
        file = open(filename, 'rb')
        text = file.read()
        file.close()

        text_start = text[text.index(UASSET_MEDIA_PATH):]
        relative_path = text_start[len(UASSET_MEDIA_PATH):text_start.index(b'\x00')].decode("utf-8") 

        print(relative_path)

        output_text += filename[0:filename.index('.uasset')] + ': ' + relative_path + '\n'

        original_filepath = WINDOWS_MEDIA_PATH + relative_path

        try:
            os.makedirs('./Sounds/' + relative_path[0:relative_path.rindex('/')])
        except:
            print('')

        shutil.copyfile(original_filepath + '.uasset', './Sounds/' + relative_path + '.uasset')
        shutil.copyfile(original_filepath + '.ubulk', './Sounds/' + relative_path + '.ubulk')
        shutil.copyfile(original_filepath + '.ubulk', WWISE_UNPACKER_GAME_FILES_PATH + relative_path[relative_path.rindex('/') + 1 : ] + '.ubulk')
        shutil.copyfile(original_filepath + '.uexp', './Sounds/' + relative_path + '.uexp')

file = open('soundmap.txt', 'w')
file.write(output_text)
file.close()

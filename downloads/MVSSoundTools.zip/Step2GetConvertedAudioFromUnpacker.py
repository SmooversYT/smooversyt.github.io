import os
import shutil

UASSET_MEDIA_PATH = b'/Game/WwiseAudio/Localized/English_US_/Media/'
WWISE_UNPACKER_MP3_PATH = './Wwise-Unpacker-1.0.3/MP3/'

try:
    os.makedirs('./RealSounds/')
except:
    print('')

try:
    os.makedirs('./ReplacementSounds/')
except:
    print('')

for filename in os.listdir('.'):
    if '.uasset' in filename:
        file = open(filename, 'rb')
        text = file.read()
        file.close()

        text_start = text[text.index(UASSET_MEDIA_PATH):]
        relative_path = text_start[len(UASSET_MEDIA_PATH):text_start.index(b'\x00')].decode("utf-8") 

        print(relative_path)

        original_filepath = WWISE_UNPACKER_MP3_PATH + relative_path[relative_path.rindex('/') + 1:] + '_1.mp3'

        shutil.copyfile(original_filepath, './RealSounds/_REPLACE_ME_' + filename[0:filename.index('.uasset')] + '.mp3')

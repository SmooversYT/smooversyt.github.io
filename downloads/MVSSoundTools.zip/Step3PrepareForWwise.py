import os
import shutil
import random

folder_name = ''
for f in os.listdir('.'):
    if 'packer' in f and '.py' not in f:
        folder_name = f

UASSET_MEDIA_PATH = b'/Game/WwiseAudio/Localized/English_US_/Media/'
WINDOWS_MEDIA_PATH = '../../../../Media/'
WWISE_UNPACKER_GAME_FILES_PATH = './' + folder_name + '/Game Files/'
WWISE_UNPACKER_MP3_PATH = './' + folder_name + '/MP3/'

try:
    os.makedirs('./ForWwiseImport/')
except:
    print('')

sound_dict = { 
    'VICTORY': [],
    'MATCHSTART': [],
    'RESPAWN': [],
    'EMOTE': [],
    'CLICKABLE': [],
    'CHASELECT': [],
    'ABILITY': [],
    'EFF': [],
    'ANNOUNCER': [],
    'STORE': [],
}

current_sound_index_dict = { 
    'VICTORY': 0,
    'MATCHSTART': 0,
    'RESPAWN': 0,
    'EMOTE': 0,
    'CLICKABLE': 0,
    'CHASELECT': 0,
    'ABILITY': 0,
    'EFF': 0,
    'ANNOUNCER': 0,
    'STORE': 0,
}

for filename in os.listdir('./ReplacementSounds/'):
    if '_' in filename:
        category = filename[0:filename.index('_')]
        sound_dict[category].append(filename)

print(sound_dict)

for key in sound_dict.keys():
    for filename in os.listdir('./RealSounds/'):
        if filename.startswith('_REPLACE_ME_') and len(sound_dict[key]) > 0 and key.lower() in filename:
            new_filename = filename[len('_REPLACE_ME_'):filename.index('.')] + '.wav'

            shutil.copyfile('./ReplacementSounds/' + sound_dict[key][current_sound_index_dict[key]], './ForWwiseImport/' + new_filename)

            current_sound_index_dict[key] = (current_sound_index_dict[key] + 1) % len(sound_dict[key])

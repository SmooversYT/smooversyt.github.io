import os
import struct
import shutil

MAX_TIME = 10
UASSET_MEDIA_PATH = b'/Game/WwiseAudio/Localized/English_US_/Media/'
WINDOWS_MEDIA_PATH = '../../../../Media/'
WWISE_UNPACKER_GAME_FILES_PATH = './Wwise-Unpacker-1.0.3/Game Files/'
WWISE_UNPACKER_MP3_PATH = './Wwise-Unpacker-1.0.3/MP3/'
WWISE_CACHE = './WwiseProject/.cache/Windows/SFX/'

map_file = open('soundmap.txt')
map_text = map_file.read()
map_file.close()

map_lines = map_text.split('\n')

map_dict = { }

for line in map_lines:
    if len(line) > 4:
        map_dict[line.split(': ')[0]] = line.split(': ')[1]

#print(map_dict)

for filename in os.listdir(WWISE_CACHE):
    if filename != 'Wwise.dat':
        real_name = filename[0:filename.rindex('_')]
        real_path = map_dict[real_name][0:map_dict[real_name].rindex('/')]
        real_id = map_dict[real_name][map_dict[real_name].rindex('/')+1:]

        try:
            os.makedirs('./_Media/' + real_path)
        except:
            print('')

        shutil.copyfile(WWISE_CACHE + filename, './_Media/' + real_path + '/' + real_id + '.ubulk')
        shutil.copyfile(WINDOWS_MEDIA_PATH + real_path + '/' + real_id + '.uasset', './_Media/' + real_path + '/' + real_id + '.uasset')
        shutil.copyfile(WINDOWS_MEDIA_PATH + real_path + '/' + real_id + '.uexp', './_Media/' + real_path + '/' + real_id + '.uexp')


        new_f = open('./_Media/' + real_path + '/' + real_id + '.uexp', 'rb')
        new_bytes = bytearray(new_f.read())
        new_f.close()


        new_f = open('./_Media/' + real_path + '/' + real_id + '.ubulk', 'rb')
        ubulk_bytes = bytearray(new_f.read())
        new_f.close()

        int_bytes = struct.pack('<I', len(ubulk_bytes))

        new_bytes[-13] = int_bytes[3]
        new_bytes[-14] = int_bytes[2]
        new_bytes[-15] = int_bytes[1]
        new_bytes[-16] = int_bytes[0]

        new_bytes[-17] = int_bytes[3]
        new_bytes[-18] = int_bytes[2]
        new_bytes[-19] = int_bytes[1]
        new_bytes[-20] = int_bytes[0]

        new_f = open('./_Media/' + real_path + '/' + real_id + '.uexp', 'wb')
        new_f.write(new_bytes)
        new_f.close()


current_character = os.getcwd().split('\\')[-1]


try:
    os.makedirs('./_Events/vo/vo_cha/' + current_character + '/')
except:
    print('')

file_num = 0
for filename in os.listdir('.'):
    if '.uexp' in filename:
        shutil.copyfile(filename, './_Events/vo/vo_cha/' + current_character + '/' + filename)
        shutil.copyfile(filename.split('.')[0] + '.uasset', './_Events/vo/vo_cha/' + current_character + '/' + filename.split('.')[0] + '.uasset')

        new_f = open('./_Events/vo/vo_cha/' + current_character + '/' + filename, 'rb')
        new_bytes = bytearray(new_f.read())
        new_f.close()

        float_bytes = struct.pack('<f', MAX_TIME)

        current_float_buffer = []
        current_float_buffer.append(new_bytes[41].to_bytes(1, 'big'))
        current_float_buffer.append(new_bytes[42].to_bytes(1, 'big'))
        current_float_buffer.append(new_bytes[43].to_bytes(1, 'big'))
        current_float_buffer.append(new_bytes[44].to_bytes(1, 'big'))
        current_float = struct.unpack('<f', b''.join(current_float_buffer))[0]

        if current_float > 1000:
            # has a max attenuation radius
            new_bytes[70] = float_bytes[0]
            new_bytes[71] = float_bytes[1]
            new_bytes[72] = float_bytes[2]
            new_bytes[73] = float_bytes[3]

            new_bytes[99] = float_bytes[0]
            new_bytes[100] = float_bytes[1]
            new_bytes[101] = float_bytes[2]
            new_bytes[102] = float_bytes[3]
        else:
            # no max attenution radius
            new_bytes[41] = float_bytes[0]
            new_bytes[42] = float_bytes[1]
            new_bytes[43] = float_bytes[2]
            new_bytes[44] = float_bytes[3]

            new_bytes[70] = float_bytes[0]
            new_bytes[71] = float_bytes[1]
            new_bytes[72] = float_bytes[2]
            new_bytes[73] = float_bytes[3]

        new_f = open('./_Events/vo/vo_cha/' + current_character + '/' + filename, 'wb')
        new_f.write(new_bytes)
        new_f.close()

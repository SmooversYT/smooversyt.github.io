import os
import re
import sys
import shutil
import subprocess

for file in os.listdir('.'):
    if '.png' in file or '.tga' in file or '.jpg' in file or '.jpeg' in file:
        image_file = file

bat_text = '"./crunch-master/bin/crunch.exe" -file "' + image_file + '" -fileformat dds -dxt1 -quality 128 -bitrate 4 '
bat_file = open('new.bat', 'w')
bat_file.write(bat_text)
bat_file.close()
subprocess.call([r'new.bat'])
os.remove('new.bat')

dds = open(image_file.split('.')[0] + '.dds', 'rb')
dds_bytes = bytearray(dds.read())
dds.close()

ubulk_bytes = []
for index in range(len(dds_bytes) - 128):
    ubulk_bytes.append(dds_bytes[index + 128])

ubulk = open(image_file.split('.')[0] + '.ubulk', 'wb')
ubulk.write(bytearray(ubulk_bytes))
ubulk.close()

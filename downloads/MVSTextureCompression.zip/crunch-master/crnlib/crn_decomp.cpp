// File: crn_decomp.cpp
// This software is in the public domain. Please see license.txt.
#include "crn_core.h"

// Include the single-file header library with no defines, which brings in the full CRN decompressor.
#include "../inc/crn_decomp.h"

#define MY_VER_MAJOR 4
#define MY_VER_MINOR 63
#define MY_VER_BUILD 0
#define MY_VERSION "4.63"
#define MY_DATE "2008-12-31"
#define MY_COPYRIGHT ": Igor Pavlov : Public domain"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION " " MY_COPYRIGHT " : " MY_DATE

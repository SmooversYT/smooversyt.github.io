import sys

input_filename = sys.argv[1]

filename = input_filename.split(".")[0]
uexp_filename = filename + ".uexp"
ubulk_filename = filename + ".ubulk"

f = open(ubulk_filename, "rb")
ubulk_file_bytes = f.read()
f.close()

ubulk_byte_count = len(ubulk_file_bytes)

f = open(uexp_filename, "rb")
uexp_file_bytes = f.read()
f.close()

new_bytes = bytearray()
new_bytes.extend(uexp_file_bytes)

new_bytes[len(uexp_file_bytes) - 20] = ubulk_byte_count & 255
new_bytes[len(uexp_file_bytes) - 19] = (ubulk_byte_count & (255 << 8)) >> 8
new_bytes[len(uexp_file_bytes) - 18] = (ubulk_byte_count & (255 << 16)) >> 16
new_bytes[len(uexp_file_bytes) - 17] = (ubulk_byte_count & (255 << 24)) >> 24

new_bytes[len(uexp_file_bytes) - 16] = ubulk_byte_count & 255
new_bytes[len(uexp_file_bytes) - 15] = (ubulk_byte_count & (255 << 8)) >> 8
new_bytes[len(uexp_file_bytes) - 14] = (ubulk_byte_count & (255 << 16)) >> 16
new_bytes[len(uexp_file_bytes) - 13] = (ubulk_byte_count & (255 << 24)) >> 24

f = open(uexp_filename, "wb")
f.write(new_bytes)
f.close()
import os
import shutil
import random

map_names = [
b'Bluedog_A',
b'Bluedog_B',
b'Bluedog_C',
b'Bluedog_D',
b'BodySnatchers_A',
b'BodySnatchers_B',
b'BodySnatchers_B2',
b'BodySnatchers_C',
b'BodySnatchers_D',
b'BodySnatchers_E',
b'CDC_A',
b'CDC_B',
b'CDC_C',
b'CDC_D',
b'Evansburgh_A',
b'Evansburgh_B',
b'Evansburgh_C',
b'Evansburgh_D',
b'Finleyville_Church_A',
b'Finleyville_Church_B',
b'Finleyville_Church_C',
b'Finleyville_Diner_A',
b'Finleyville_Diner_B',
b'Finleyville_Police_A',
b'Finleyville_Police_B',
b'Finleyville_Rescue_A',
b'Finleyville_Rescue_B',
b'Finleyville_Rescue_C',
b'Manor_A',
b'Manor_B',
b'Manor_C',
b'Manor_D',
b'Manor_E',
b'TheClog_A',
b'TheClog_B',
b'TheClog_C',
b'TheClog_D',
b'TheClog_E',
b'TitanTunnels_A'
]

replacements = [
b'XXXXXXXXXXXXXXXXXXXXXA',
b'XXXXXXXXXXXXXXXXXXXXXB',
b'XXXXXXXXXXXXXXXXXXXXXC',
b'XXXXXXXXXXXXXXXXXXXXXD',
b'XXXXXXXXXXXXXXXXXXXXXE',
b'XXXXXXXXXXXXXXXXXXXXXF',
b'XXXXXXXXXXXXXXXXXXXXXG',
b'XXXXXXXXXXXXXXXXXXXXXH',
b'XXXXXXXXXXXXXXXXXXXXXI',
b'XXXXXXXXXXXXXXXXXXXXXJ',
b'XXXXXXXXXXXXXXXXXXXXXK',
b'XXXXXXXXXXXXXXXXXXXXXL',
b'XXXXXXXXXXXXXXXXXXXXXM',
b'XXXXXXXXXXXXXXXXXXXXXN',
b'XXXXXXXXXXXXXXXXXXXXXO',
b'XXXXXXXXXXXXXXXXXXXXXP',
b'XXXXXXXXXXXXXXXXXXXXXQ',
b'XXXXXXXXXXXXXXXXXXXXXR',
b'XXXXXXXXXXXXXXXXXXXXXS',
b'XXXXXXXXXXXXXXXXXXXXXT',
b'XXXXXXXXXXXXXXXXXXXXXU',
b'XXXXXXXXXXXXXXXXXXXXXV',
b'XXXXXXXXXXXXXXXXXXXXXW',
b'XXXXXXXXXXXXXXXXXXXXXX',
b'XXXXXXXXXXXXXXXXXXXXXY',
b'XXXXXXXXXXXXXXXXXXXXXZ',
b'XXXXXXXXXXXXXXXXXXXXX1',
b'XXXXXXXXXXXXXXXXXXXXX2',
b'XXXXXXXXXXXXXXXXXXXXX3',
b'XXXXXXXXXXXXXXXXXXXXX4',
b'XXXXXXXXXXXXXXXXXXXXX5',
b'XXXXXXXXXXXXXXXXXXXXX6',
b'XXXXXXXXXXXXXXXXXXXXX7',
b'XXXXXXXXXXXXXXXXXXXXX8',
b'XXXXXXXXXXXXXXXXXXXXX9',
b'XXXXXXXXXXXXXXXXXXXX10',
b'XXXXXXXXXXXXXXXXXXXX11',
b'XXXXXXXXXXXXXXXXXXXX12',
b'XXXXXXXXXXXXXXXXXXXX13'
]

base_pak_file = open("Base.pak", "rb")
base_pak_bytes = bytearray(base_pak_file.read())
base_pak_file.close()

for replacement_string in replacements:
    map_index = random.randint(0, len(map_names) - 1)
    print(map_index)
    random_map_name = map_names[map_index]
    map_names.remove(random_map_name)
    for index in range(0, len(replacement_string) - len(random_map_name)):
        random_map_name += b'\x00'
    base_pak_bytes = base_pak_bytes.replace(replacement_string, random_map_name)

new_pak_file = open("RandomActMod_P.pak", "wb")
new_pak_file.write(base_pak_bytes)
new_pak_file.close()
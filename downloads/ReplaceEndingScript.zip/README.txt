To use, drag your .pak onto the .bat file.

Make sure you have Python installed - https://www.python.org/downloads/
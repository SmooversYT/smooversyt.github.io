To use, unzip to a folder and drag your .pak onto the .bat file.

Make sure you have Python installed - https://www.python.org/downloads/
import os
import sys

print(sys.argv[1])
pak_file = open(sys.argv[1], 'rb')
pak_data = pak_file.read()
pak_file.close()

pak_data = pak_data[0:pak_data.rindex(b'\xe1\x12\x6f\x5a\x03')] + b'\x09\x00\x00\x00\x5d\x3e\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' + pak_data[pak_data.rindex(b'\xe1\x12\x6f\x5a\x03') + len(b'\xe1\x12\x6f\x5a\x03'):] 

new_pak_file = open(sys.argv[1], 'wb')
new_pak_file.write(pak_data)
new_pak_file.close()

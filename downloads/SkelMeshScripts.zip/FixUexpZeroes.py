import os 
import sys

default_LOD_ending = b'\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x01\x00\x00\x00'
new_LOD_ending =     b'\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x01\x00\x00\x00'

filename = sys.argv[1]

f = open(filename, 'rb')
uexp_data = f.read()
f.close()

remaining_data = b''

while default_LOD_ending in uexp_data:
    next_index = uexp_data.index(default_LOD_ending)
    remaining_data += uexp_data[0:next_index] 
    remaining_data += new_LOD_ending
    uexp_data = uexp_data[next_index + len(default_LOD_ending):]

remaining_data += uexp_data

remaining_data = remaining_data[:-10] + b'\x00\x00\x00\x00\x00\x00\x00\x00' + remaining_data[-10:]

f = open(filename, 'wb')
f.write(remaining_data)
f.close()

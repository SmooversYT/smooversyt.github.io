To use the .uexp SkelMesh fixer, drag your .uexp onto the .py script.
The file will be overwritten in place, so don't attempt to use it twice.
Make sure you have Python installed.
To be sure it worked, you can manually check that the ending of the file is correct in HxD, that the filesize increased, or run the script from the command line.
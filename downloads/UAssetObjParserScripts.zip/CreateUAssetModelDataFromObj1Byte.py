import os
import struct

f_obj = open("VerticesOutput.txt")
text_obj = f_obj.read()
lines_obj = text_obj.strip().split('\n')
f_obj.close()

HEADER_LINE_LENGTH = 3
VERTEX_COUNT = len(lines_obj)

f_new = open("output_new.obj")
text_new = f_new.read()
lines = text_new.strip().split('\n')
f_new.close()

CHARS_PER_FLOAT = 8
FLOATS_PER_VERTEX = 3 
FLOATS_PER_TEX_COORD = 2
FLOATS_PER_NORMAL = 3 
FLOATS_PER_FACE = 3 

vertices = lines[HEADER_LINE_LENGTH : HEADER_LINE_LENGTH + VERTEX_COUNT]
faces = lines[HEADER_LINE_LENGTH + VERTEX_COUNT + 2 : ]

v_file = open("output_v.txt", 'w')
f_file = open("output_f.txt", 'w')

for v in range(VERTEX_COUNT):
	components = vertices[v].split(' ')
	v_x = float(components[1])
	v_y = float(components[2])
	v_z = float(components[3])
	v_x = struct.pack('f', v_x).hex()
	v_y = struct.pack('f', v_y).hex()
	v_z = struct.pack('f', v_z).hex()
	v_file.write(v_x + v_y + v_z)

for f in range(len(faces)):
	components = faces[f].split(' ')
	v_1 = int(components[1]) - 1
	v_2 = int(components[2]) - 1
	v_3 = int(components[3]) - 1
	v_1 = struct.pack('B', v_1).hex()
	v_2 = struct.pack('B', v_2).hex()
	v_3 = struct.pack('B', v_3).hex()
	f_file.write(v_1 + v_2 + v_3)

v_file.close()
f_file.close()
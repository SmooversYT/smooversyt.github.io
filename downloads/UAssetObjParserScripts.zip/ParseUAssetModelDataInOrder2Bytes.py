import os
import struct

VERTEX_COUNT = 27291
FACE_COUNT = 25359

#LOD1
#VERTEX_COUNT = 54367
#FACE_COUNT = 56855

#LOD2
#VERTEX_COUNT = 45459
#FACE_COUNT = 45039

#LOD3
#VERTEX_COUNT = 27291
#FACE_COUNT = 25359

#LOD4
#FACE_COUNT = 9637

f_v = open("EvanModelData1.txt")
f_f = open("EvanModelData5.txt")

text_v = f_v.read()
text_f = f_f.read()

f_v.close()
f_f.close()

text_v = text_v.replace(' ', '')
text_f = text_f.replace(' ', '')

CHARS_PER_FLOAT = 8
CHARS_PER_INT = 4
FLOATS_PER_VERTEX = 3 
FLOATS_PER_TEX_COORD = 2
FLOATS_PER_NORMAL = 3 
INTS_PER_FACE = 3 

vertex_count = len(text_v) / (CHARS_PER_FLOAT * FLOATS_PER_VERTEX)
face_count = len(text_f) / (CHARS_PER_INT * INTS_PER_FACE)

#print("Vertices:")
#print(vertex_count)
#print("Tex Coords:")
#print(len(text_vt) / (CHARS_PER_BYTE * BYTES_PER_FLOAT * FLOATS_PER_TEX_COORD))
#print("Normals:")
#print(len(text_vn) / (CHARS_PER_BYTE * BYTES_PER_FLOAT * FLOATS_PER_NORMAL))
#print("Faces:")
#print(len(text_f) / (CHARS_PER_BYTE * BYTES_PER_FLOAT * FLOATS_PER_FACE))


vertices = []
faces = []

obj_file = open("output.obj", 'w')
obj_file.write("o Output\n")

for v in range(int(vertex_count)):
	v_x = text_v[CHARS_PER_FLOAT * 0 : CHARS_PER_FLOAT * 1]
	v_y = text_v[CHARS_PER_FLOAT * 1 : CHARS_PER_FLOAT * 2]
	v_z = text_v[CHARS_PER_FLOAT * 2 : CHARS_PER_FLOAT * 3]
	v_x = v_x[6:8] + v_x[4:6] + v_x[2:4] + v_x[0:2]
	v_y = v_y[6:8] + v_y[4:6] + v_y[2:4] + v_y[0:2]
	v_z = v_z[6:8] + v_z[4:6] + v_z[2:4] + v_z[0:2]
	v_x = struct.unpack('!f', bytes.fromhex(v_x))[0]
	v_y = struct.unpack('!f', bytes.fromhex(v_y))[0]
	v_z = struct.unpack('!f', bytes.fromhex(v_z))[0]
	vertices.append((v_x, v_y, v_z))
	obj_file.write("v " + str(v_x) + " " + str(v_y) + " "  + str(v_z) + "\n")
	text_v = text_v[CHARS_PER_FLOAT * 3 : ]

obj_file.write("usemtl None\n")
obj_file.write("s off\n")

for f in range(int(face_count)):
	v_1 = text_f[CHARS_PER_INT * 0 : CHARS_PER_INT * 1]
	v_2 = text_f[CHARS_PER_INT * 1 : CHARS_PER_INT * 2]
	v_3 = text_f[CHARS_PER_INT * 2 : CHARS_PER_INT * 3]
	v_1 = "0000" + v_1[2:4] + v_1[0:2]
	v_2 = "0000" + v_2[2:4] + v_2[0:2]
	v_3 = "0000" + v_3[2:4] + v_3[0:2]
	v_1 = struct.unpack('!I', bytes.fromhex(v_1))[0] + 1
	v_2 = struct.unpack('!I', bytes.fromhex(v_2))[0] + 1
	v_3 = struct.unpack('!I', bytes.fromhex(v_3))[0] + 1
	faces.append((v_1, v_2, v_3))
	obj_file.write("f " + str(v_1) + " " + str(v_2) + " "  + str(v_3) + "\n")
	text_f = text_f[CHARS_PER_INT * 3 : ]

print("Done.")




import os
import struct

f_v = open("VertexData.txt")
f_f = open("FaceData.txt")

text_v = f_v.read()
text_f = f_f.read()

f_v.close()
f_f.close()

text_v = text_v.replace(' ', '')
text_f = text_f.replace(' ', '')

CHARS_PER_FLOAT = 8
FLOATS_PER_VERTEX = 3 
FLOATS_PER_TEX_COORD = 2
FLOATS_PER_NORMAL = 3 
FLOATS_PER_FACE = 3 

vertex_count = len(text_v) / (CHARS_PER_FLOAT * FLOATS_PER_VERTEX)
face_count = len(text_f) / (CHARS_PER_FLOAT * FLOATS_PER_FACE)

vertices = []
faces = []

obj_file = open("output.obj", 'w')
obj_file.write("o Output\n")

for v in range(int(vertex_count)):
	v_x = text_v[CHARS_PER_FLOAT * 0 : CHARS_PER_FLOAT * 1]
	v_y = text_v[CHARS_PER_FLOAT * 1 : CHARS_PER_FLOAT * 2]
	v_z = text_v[CHARS_PER_FLOAT * 2 : CHARS_PER_FLOAT * 3]
	v_x = v_x[6:8] + v_x[4:6] + v_x[2:4] + v_x[0:2]
	v_y = v_y[6:8] + v_y[4:6] + v_y[2:4] + v_y[0:2]
	v_z = v_z[6:8] + v_z[4:6] + v_z[2:4] + v_z[0:2]
	v_x = struct.unpack('!f', bytes.fromhex(v_x))[0]
	v_y = struct.unpack('!f', bytes.fromhex(v_y))[0]
	v_z = struct.unpack('!f', bytes.fromhex(v_z))[0]
	vertices.append((v_x, v_y, v_z))
	obj_file.write("v " + str(v_x) + " " + str(v_y) + " "  + str(v_z) + "\n")
	text_v = text_v[CHARS_PER_FLOAT * 3 : ]

obj_file.write("usemtl None\n")
obj_file.write("s off\n")

for f in range(int(face_count)):
	v_1 = text_f[CHARS_PER_FLOAT * 0 : CHARS_PER_FLOAT * 1]
	v_2 = text_f[CHARS_PER_FLOAT * 1 : CHARS_PER_FLOAT * 2]
	v_3 = text_f[CHARS_PER_FLOAT * 2 : CHARS_PER_FLOAT * 3]
	v_1 = v_1[6:8] + v_1[4:6] + v_1[2:4] + v_1[0:2]
	v_2 = v_2[6:8] + v_2[4:6] + v_2[2:4] + v_2[0:2]
	v_3 = v_3[6:8] + v_3[4:6] + v_3[2:4] + v_3[0:2]
	v_1 = struct.unpack('!I', bytes.fromhex(v_1))[0] + 1
	v_2 = struct.unpack('!I', bytes.fromhex(v_2))[0] + 1
	v_3 = struct.unpack('!I', bytes.fromhex(v_3))[0] + 1
	faces.append((v_1, v_2, v_3))
	obj_file.write("f " + str(v_1) + " " + str(v_2) + " "  + str(v_3) + "\n")
	text_f = text_f[CHARS_PER_FLOAT * 3 : ]

print("Done.")




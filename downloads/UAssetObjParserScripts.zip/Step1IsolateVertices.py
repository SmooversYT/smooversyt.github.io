import os

# File reading
f_obj = open("output.obj")
f_merged = open("output_merged.obj")

text_obj = f_obj.read()
text_merged = f_merged.read()

f_obj.close()
f_merged.close()

# Editing text
text_obj = text_obj[text_obj.index('v ') : text_obj.index('usemtl None')]
text_obj = text_obj.replace('v ', '')

text_merged = text_merged[text_merged.index('v ') : text_merged.index('s off')]
text_merged = text_merged.replace('v ', '')

# File writing
v_obj_file = open("VerticesOutput.txt", 'w')
v_merged_file = open("VerticesOutputMerged.txt", 'w')

v_obj_file.write(text_obj)
v_merged_file.write(text_merged)

v_obj_file.close()
v_merged_file.close()
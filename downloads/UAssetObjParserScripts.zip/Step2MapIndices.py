import os
import numpy as np

f_obj = open("VerticesOutput.txt")
f_merged = open("VerticesOutputMerged.txt")
text_obj = f_obj.read()
text_merged = f_merged.read()
lines_obj = text_obj.strip().split('\n')
lines_merged = text_merged.strip().split('\n')
f_obj.close()
f_merged.close()

CHARS_PER_FLOAT = 8
FLOATS_PER_VERTEX = 3 
FLOATS_PER_TEX_COORD = 2
FLOATS_PER_NORMAL = 3 
FLOATS_PER_FACE = 3 

vertices_map = []

map_file = open("VertexMap.txt", 'w')

all_v = []
all_u = []

u_dict = { }
corresponding_v = []

for u in range(len(lines_merged)):
	merged_components = lines_merged[u].split(' ')
	merged_index = str(u)
	u_x = round(float(merged_components[0]), 3)
	u_y = round(float(merged_components[1]), 3)
	u_z = round(float(merged_components[2]), 3)
	u_vec = np.array([u_x, u_y, u_z])
	all_u.append((merged_index, u_vec))

	x_coord = str(u_x)
	if u_x == 0:
		x_coord = "0.000"
	if len(x_coord.split('.')[1]) == 1:
		x_coord += "00"
	if len(x_coord.split('.')[1]) == 2:
		x_coord += "0"

	y_coord = str(u_y)
	if u_y == 0:
		y_coord = "0.000"
	if len(y_coord.split('.')[1]) == 1:
		y_coord += "00"
	if len(y_coord.split('.')[1]) == 2:
		y_coord += "0"

	z_coord = str(u_z)
	if u_z == 0:
		z_coord = "0.000"
	if len(z_coord.split('.')[1]) == 1:
		z_coord += "00"
	if len(z_coord.split('.')[1]) == 2:
		z_coord += "0"

	u_name = x_coord + " " + y_coord + " " + z_coord
	u_dict[u_name] = merged_index

	if u > 150 and u < 160:
		print(u_name)

for v in range(len(lines_obj)):
	obj_components = lines_obj[v].split(' ')
	obj_index = str(v)
	v_x = round(float(obj_components[0]), 3)
	v_y = round(float(obj_components[1]), 3)
	v_z = round(float(obj_components[2]), 3)
	v_vec = np.array([v_x, v_y, v_z])
	all_v.append((obj_index, v_vec))

	is_found = False
	diff = 0.001
	while not is_found:
		possible_v_names = []
		for x_diff in [-diff, 0, diff]:
			for y_diff in [-diff, 0, diff]:
				for z_diff in [-diff, 0, diff]:


					new_x = round(v_x + x_diff, 3)
					x_coord = str(new_x)
					if new_x == 0:
						x_coord = "0.000"
					if len(x_coord.split('.')[1]) == 1:
						x_coord += "00"
					if len(x_coord.split('.')[1]) == 2:
						x_coord += "0"

					new_y = round(v_y + y_diff, 3)
					y_coord = str(new_y)
					if new_y == 0:
						y_coord = "0.000"
					if len(y_coord.split('.')[1]) == 1:
						y_coord += "00"
					if len(y_coord.split('.')[1]) == 2:
						y_coord += "0"

					new_z = round(v_z + z_diff, 3)
					z_coord = str(new_z)
					if new_z == 0:
						z_coord = "0.000"
					if len(z_coord.split('.')[1]) == 1:
						z_coord += "00"
					if len(z_coord.split('.')[1]) == 2:
						z_coord += "0"

					v_name = x_coord + " " + y_coord + " " + z_coord
					possible_v_names.append(v_name)

		for v_name in possible_v_names:
			if v_name in u_dict.keys():
				corresponding_u = u_dict[v_name]
				is_found = True

		diff += 0.001

	corresponding_v.append(obj_index + " " + corresponding_u)
	print(obj_index + "/" + str(len(lines_obj)) + " vertices mapped.", flush=True)

for new_line in corresponding_v:
	map_file.write(new_line + "\n")

map_file.close()
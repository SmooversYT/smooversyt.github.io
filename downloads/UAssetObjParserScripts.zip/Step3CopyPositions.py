import os
import numpy as np

f_map = open("VertexMap.txt")
text_map = f_map.read()
lines_map = text_map.strip().split('\n')
f_map.close()

f_obj = open("output.obj")
text_obj = f_obj.read()
lines_obj = text_obj.strip().split('\n')
f_obj.close()

f_edited = open("output_edited.obj")
text_edited = f_edited.read()
lines_edited = text_edited.strip().split('\n')
f_edited.close()


f_orig = open("VerticesOutput.txt")
f_merged = open("VerticesOutputMerged.txt")
text_orig = f_orig.read()
text_merged = f_merged.read()
lines_orig = text_orig.strip().split('\n')
lines_merged = text_merged.strip().split('\n')
f_orig.close()
f_merged.close()

OBJ_HEADER_LINE_LENGTH = 1
OBJ_VERTEX_COUNT = len(lines_orig)

EDITED_HEADER_LINE_LENGTH = 3
EDITED_VERTEX_COUNT = len(lines_merged)

vertex_map = []

for v_index in range(OBJ_VERTEX_COUNT):
	mapped_u = lines_map[v_index].split(' ')[1]
	vertex_map.append(mapped_u)

vertices_obj = lines_obj[OBJ_HEADER_LINE_LENGTH : OBJ_HEADER_LINE_LENGTH + OBJ_VERTEX_COUNT]
faces_obj = lines_obj[OBJ_HEADER_LINE_LENGTH + OBJ_VERTEX_COUNT : ]

vertices_edited = lines_edited[EDITED_HEADER_LINE_LENGTH : EDITED_HEADER_LINE_LENGTH + EDITED_VERTEX_COUNT]

f_new = open("output_new.obj", "w")
f_new.write(lines_edited[0] + "\n")
f_new.write(lines_edited[1] + "\n")
f_new.write(lines_edited[2] + "\n")

for v_index in range(OBJ_VERTEX_COUNT):

	u_index = int(vertex_map[v_index])
	u_components = vertices_edited[u_index].split(' ')
	u_x = u_components[1]
	u_y = u_components[2]
	u_z = u_components[3]
	f_new.write("v " + u_x + " " + u_y + " " + u_z + "\n")

for f_line in faces_obj:
	f_new.write(f_line + "\n")

f_new.close()